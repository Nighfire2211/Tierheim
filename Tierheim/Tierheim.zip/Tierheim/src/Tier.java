import java.util.ArrayList;

public class Tier
{
    private Tierart tierart;
    private String name;

    public Tier(Tierart t)
    {
        setTierart(t);
        t.alleDatenAusgaben(t.getName(),t.getAnzahlBeine());

    }

    public Tierart getTierart() {
        return tierart;
    }

    public void setTierart(Tierart tierart) {
        this.tierart = tierart;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }



}
