public class Tierart {

    private int anzahlBeine;
    private String name;

    public Tierart(String n, int b)
    {
        setAnzahlBeine(b);
        setName(n);

        alleDatenAusgaben(n,b);
    }

    public int getAnzahlBeine() {
        return anzahlBeine;
    }

    public void setAnzahlBeine(int anzahlBeine) {
        this.anzahlBeine = anzahlBeine;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void alleDatenAusgaben(String name,int anzahlBeine)
    {

        System.out.println("Tierart: "+name+" Anzahl Beine: "+anzahlBeine);
    }
}